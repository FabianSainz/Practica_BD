<?php
//entidad de productos
//clase de productos
class Productos{
    //definir atributos


    //definir los metodos de inserccion y guardado de datos en BD
}
?>