<?php
    require_once 'Helper/Cls_Conexion.php';

    class Usuarios{
        private $_nombre;
        private $_correo;
        private $_contrasena;
        private $_foto;
        private $_perfil;
        private $_estatus;

        public function SetDatos($corr,$nom,$cont,$foto){
            $this->_correo=$corr;
            $this->_nombre=$nom;
            $this->_contrasena=$cont;
            $this->_foto=$foto;
        }

        public function insertarUsuarios(){
            $nombreFoto=$this->_foto['foto']['name'];
            $ruta='Vista/catalogo/clientes'.$nombreFoto;
            move_uploaded_file($this->_foto['foto']['tmp_name'],$ruta);

            $sql="insert into usuarios values('$this->_correo','$this->_nombre',sha2('$this->_contrasena',256),'$ruta',1,1)";
            $res=$this->_aplicarQuery($sql);
            return $res;
            var_dump($res);
        }

        public function login(){
            $sql="select nombre, perfil, foto from usuarios where correo = '$this->_correo' && contrasena =sha2('$this->_contrasena',256)";
            $res= $this->_aplicarQuery($sql);
        }

        public function _aplicarQuery($consulta){
            $objConexion = new Conexion();
            $res=$objConexion->ejecutarConsulta($consulta);
            $objConexion->cerrarConexion();
            return $res;
        }
    }
?>
</body>
</html>