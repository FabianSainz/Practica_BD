<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Vista/css/estilos.css">
    <title>Conexion a BD</title>
</head>
<body>
    <header><h1>Proyecto EVN304</h1></header>
    <nav id="menuPrincipal">
        <a class="opcionMenu" href="?peticion=home">Home</a>
        <a class="opcionMenu" href="?peticion=somos">Quienes Somos</a>
        <a class="opcionMenu" href="?peticion=galeria">Galeria</a>
        <a class="opcionMenu" href="?peticion=login">Inicio de Sesión</a>
    </nav>
    <section>
        <h2>Quienes Somos</h2>
    </section>
</body>
</html>

<?php

?>