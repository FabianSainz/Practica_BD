<?php
    require_once 'config.php';
    require_once 'Controlador/master.php';
?>