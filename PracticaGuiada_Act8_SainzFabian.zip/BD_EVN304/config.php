<?php
    define('SERVIDOR','Localhost');
    define('USUARIO','root');
    define('CONTRASENA','');
    define('BASE_DATOS','bdevn304');
?>